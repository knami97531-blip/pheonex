package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Design Palette (from HTML specification)
val SleekBg = Color(0xFFF3F4F9)
val SleekSurface = Color(0xFFFFFFFF)
val SleekSurfaceVariant = Color(0xFFE2E2E6)
val SleekBorder = Color(0xFFDEE2F2)
val SleekPrimary = Color(0xFF005FB0)
val SleekPrimaryContainer = Color(0xFFD6E3FF)
val SleekOnPrimaryContainer = Color(0xFF001B3D)
val SleekTextPrimary = Color(0xFF1B1B1F)
val SleekTextSecondary = Color(0xFF44474E)
val SleekTextMuted = Color(0xFF74777F)
val SleekGreen = Color(0xFF22C55E)

// Component & Legacy Color Mappings for Sleek Interface
val PhoenixFlame = SleekPrimary
val PhoenixAmber = SleekPrimary
val PhoenixGlow = SleekPrimaryContainer
val PhoenixCyan = SleekPrimary
val PhoenixGreen = SleekGreen

val ObsidianBg = SleekBg
val ObsidianSurface = SleekSurface
val ObsidianSurfaceVariant = SleekSurfaceVariant
val ObsidianBorder = SleekBorder

val TextPrimary = SleekTextPrimary
val TextSecondary = SleekTextSecondary
val TextMuted = SleekTextMuted

// Dark counterpart to the Sleek palette, kept alongside the existing light
// colors above (not wired in as the default — see Theme.kt).
val SleekDarkBg = Color(0xFF121218)
val SleekDarkSurface = Color(0xFF1C1C24)
val SleekDarkSurfaceVariant = Color(0xFF2A2A34)
val SleekDarkBorder = Color(0xFF35353F)
val SleekDarkPrimary = Color(0xFF9DC3FF)
val SleekDarkPrimaryContainer = Color(0xFF1E3A66)
val SleekDarkOnPrimaryContainer = Color(0xFFD6E3FF)
val SleekDarkTextPrimary = Color(0xFFECEDF3)
val SleekDarkTextSecondary = Color(0xFFB7B9C6)
val SleekDarkTextMuted = Color(0xFF8B8D9A)
