package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.example.data.local.ChatMessageEntity
import com.example.device.SafeAction
import com.example.ui.components.ActionCardView
import com.example.ui.components.OfflineVoicePrivacyBanner
import com.example.ui.components.SafetyShieldBadge
import com.example.ui.components.TypingIndicatorDots
import com.example.ui.components.VoicePulseOrb
import com.example.ui.theme.SleekBg
import com.example.ui.theme.SleekBorder
import com.example.ui.theme.SleekGreen
import com.example.ui.theme.SleekOnPrimaryContainer
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekSurface
import com.example.ui.theme.SleekSurfaceVariant
import com.example.ui.theme.SleekTextMuted
import com.example.ui.theme.SleekTextPrimary
import com.example.ui.theme.SleekTextSecondary
import com.example.voice.VoiceState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    messages: List<ChatMessageEntity>,
    isGenerating: Boolean,
    voiceState: VoiceState,
    audioRms: Float,
    transcription: String,
    onSendMessage: (String) -> Unit,
    onVoiceTrigger: () -> Unit,
    onExecuteAction: (SafeAction) -> Unit,
    onRunCodeInSandbox: (String, String) -> Unit,
    onClearChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SleekBg)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(6.dp))

        // Privacy & Wake Word Banner
        OfflineVoicePrivacyBanner(
            isOffline = true,
            wakeWordActive = voiceState != VoiceState.IDLE
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Realtime speech transcription bar
        AnimatedVisibility(
            visible = transcription.isNotBlank() || voiceState == VoiceState.WAKE_WORD_ACTIVATED,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(
                color = SleekPrimaryContainer,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Live Voice",
                        tint = SleekPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (transcription.isNotBlank()) "Voice Input: \"$transcription\"" else "Hey Phoenix activated! Listening for command...",
                        color = SleekOnPrimaryContainer,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Main Content Area: If no messages, show Sleek Hero Assistant Card & Local Execution Panel
        if (messages.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Sleek Main Assistant Hero Card (matching design HTML)
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekSurface),
                    shape = RoundedCornerShape(32.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(32.dp), spotColor = SleekBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Online Status Pill Tag
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(SleekGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LLAMA 3 ONLINE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.8.sp,
                                color = SleekTextSecondary
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Layered Voice Pulse Visualizer
                        SleekVoiceHeroVisualizer(
                            voiceState = voiceState,
                            audioRms = audioRms,
                            onClick = onVoiceTrigger
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "'Hey Phoenix...'",
                            fontStyle = FontStyle.Italic,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = SleekTextSecondary
                        )
                        Text(
                            text = when (voiceState) {
                                VoiceState.WAKE_WORD_ACTIVATED -> "Wake Word Detected!"
                                VoiceState.LISTENING_FOR_WAKE_WORD -> "Listening..."
                                VoiceState.PROCESSING_COMMAND -> "Processing Command..."
                                else -> "Ready for Voice or Chat"
                            },
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SleekTextPrimary
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Recent Command Highlight Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SleekBg),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier
                                        .width(4.dp)
                                        .height(58.dp)
                                        .background(SleekPrimary)
                                )
                                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                    Text(
                                        text = "SAMPLE VOICE COMMAND",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp,
                                        color = SleekTextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "\"Hey Phoenix, open spotify and play stay by justin bieber\"",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = SleekTextPrimary,
                                        modifier = Modifier.clickable {
                                            onSendMessage("open spotify and play stay by justin bieber")
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Sleek Local Execution Section
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekPrimaryContainer),
                    shape = RoundedCornerShape(32.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Local Execution",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SleekOnPrimaryContainer
                            )
                            Surface(
                                color = Color.White.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "PRIVATE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SleekOnPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Terminal row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White.copy(alpha = 0.5f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Terminal",
                                tint = SleekPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "spotify --action=play --query=\"Stay\"",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = SleekOnPrimaryContainer
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Notepad row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White.copy(alpha = 0.5f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = "Notepad",
                                tint = SleekPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Notepad & local tasks verified safe (no exploits)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = SleekOnPrimaryContainer
                            )
                        }
                    }
                }
            }
        } else {
            // Chat Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatMessageRow(
                        message = message,
                        onExecuteAction = onExecuteAction,
                        onRunCode = onRunCodeInSandbox
                    )
                }

                if (isGenerating) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                        ) {
                            TypingIndicatorDots(dotColor = SleekPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Phoenix is thinking with Llama model...",
                                color = SleekTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Suggested Prompt Chips
        val suggestions = listOf(
            "Hey Phoenix, open spotify and play stay by justin bieber",
            "Open notepad and write grocery list: milk, eggs, bread",
            "Search on google for Llama 3.3 model architecture",
            "Run code: sqrt(144) + pow(2, 4)",
            "Build me a simple portfolio website homepage",
            "Generate an image of a phoenix rising from flames"
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            suggestions.forEach { chipText ->
                Surface(
                    color = SleekSurfaceVariant,
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
                    modifier = Modifier.clickable {
                        onSendMessage(chipText)
                    }
                ) {
                    Text(
                        text = chipText,
                        color = SleekTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Input & Voice Action Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text("Ask Phoenix or speak trigger...", color = SleekTextMuted, fontSize = 13.sp)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SleekSurface,
                    unfocusedContainerColor = SleekSurface,
                    focusedBorderColor = SleekPrimary,
                    unfocusedBorderColor = SleekBorder,
                    focusedTextColor = SleekTextPrimary,
                    unfocusedTextColor = SleekTextPrimary
                ),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Pulsing Mic Trigger Orb
            VoicePulseOrb(
                voiceState = voiceState,
                audioRms = audioRms,
                onClick = onVoiceTrigger
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Send Button
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        val text = inputText
                        inputText = ""
                        onSendMessage(text)
                    }
                },
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(SleekPrimary)
                    .testTag("chat_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send Message",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun SleekVoiceHeroVisualizer(
    voiceState: VoiceState,
    audioRms: Float,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "heroPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val isActive = voiceState == VoiceState.LISTENING_FOR_WAKE_WORD || voiceState == VoiceState.WAKE_WORD_ACTIVATED
    val effectiveScale = if (isActive) (pulseScale + audioRms * 0.3f).coerceIn(1f, 1.35f) else 1.0f

    // Outer: w-48 h-48 rounded-full bg-[#D6E3FF]/30
    Box(
        modifier = Modifier
            .size(160.dp)
            .clip(CircleShape)
            .background(SleekPrimaryContainer.copy(alpha = 0.35f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Middle: w-40 h-40 rounded-full bg-[#D6E3FF]/60
        Box(
            modifier = Modifier
                .size(130.dp)
                .scale(effectiveScale)
                .clip(CircleShape)
                .background(SleekPrimaryContainer.copy(alpha = 0.65f)),
            contentAlignment = Alignment.Center
        ) {
            // Center: w-32 h-32 rounded-full bg-[#005FB0]
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(SleekPrimary)
                    .shadow(12.dp, CircleShape, spotColor = SleekPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = "Voice Graphic Equalizer",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }
    }
}

@Composable
fun ChatMessageRow(
    message: ChatMessageEntity,
    onExecuteAction: (SafeAction) -> Unit,
    onRunCode: (String, String) -> Unit
) {
    val isUser = message.role == "user"
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val formattedTime = timeFormat.format(Date(message.timestamp))

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            if (!isUser) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "Phoenix Assistant",
                    tint = SleekPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Phoenix",
                    color = SleekPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            } else if (message.isVoiceTriggered) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Triggered",
                    tint = SleekPrimary,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Voice Trigger",
                    color = SleekPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = formattedTime,
                color = SleekTextMuted,
                fontSize = 10.sp
            )
        }

        Surface(
            color = if (isUser) SleekPrimaryContainer else SleekSurface,
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isUser) 20.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 20.dp
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isUser) SleekPrimaryContainer else SleekBorder
            ),
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // If content has code blocks: ```code```
                if (message.content.contains("```")) {
                    MessageWithCodeBlock(message.content, onRunCode = onRunCode)
                } else {
                    Text(
                        text = message.content,
                        color = if (isUser) SleekOnPrimaryContainer else SleekTextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }

                // If message is associated with a device action
                if (message.actionType == "GENERATE_IMAGE" && message.actionPayload != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = message.actionPayload,
                        contentDescription = "Generated image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(16.dp))
                    )
                } else if (message.actionType != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    ActionCardView(
                        actionType = message.actionType,
                        title = "Device Task: ${message.actionType.replace("_", " ")}",
                        details = message.actionPayload ?: message.content,
                        status = message.actionStatus ?: "SUCCESS",
                        onExecuteAgain = {
                            val parsed = SafeAction.parseFromText(message.actionPayload ?: message.content)
                            if (parsed != null) onExecuteAction(parsed)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun MessageWithCodeBlock(content: String, onRunCode: (String, String) -> Unit) {
    val parts = content.split("```")
    Column {
        parts.forEachIndexed { index, part ->
            if (index % 2 == 0) {
                // Normal text
                if (part.isNotBlank()) {
                    Text(
                        text = part.trim(),
                        color = SleekTextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            } else {
                // Code block
                val lang = part.lines().firstOrNull()?.trim() ?: "kotlin"
                val actualCode = part.lines().drop(1).joinToString("\n").trim().ifBlank { part.trim() }

                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekSurfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SleekBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = lang.uppercase(),
                                color = SleekPrimary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SleekPrimaryContainer)
                                    .clickable { onRunCode(actualCode, lang.ifBlank { "kotlin" }) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Run Code in Sandbox",
                                    tint = SleekPrimary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Run in Sandbox",
                                    color = SleekOnPrimaryContainer,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = actualCode,
                            color = SleekTextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
