package com.example.sandbox

import kotlin.math.*

data class CodeExecutionResult(
    val isSuccess: Boolean,
    val stdout: String,
    val returnValue: String,
    val executionTimeMs: Long,
    val securityBadge: String = "SANDBOX SECURED • Zero Exploit Isolated",
    val errorMessage: String? = null,
    val htmlPreview: String? = null
)

class CodeSandboxEngine {

    // Strictly forbidden dangerous keywords
    private val forbiddenKeywords = listOf(
        "runtime", "processbuilder", "class.forname", "system.exit",
        "fileinputstream", "fileoutputstream", "socket", "urlconnection",
        "reflection", "method.invoke", "thread", "forkjoin", "native"
    )

    fun execute(rawCode: String, language: String = "kotlin"): CodeExecutionResult {
        val startTime = System.currentTimeMillis()
        val lower = rawCode.lowercase()

        // Website / HTML generation: rendered as a live preview instead of
        // being run through the Kotlin-like mini-interpreter below.
        if (language.lowercase() in setOf("html", "web", "website")) {
            val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            return CodeExecutionResult(
                isSuccess = true,
                stdout = "Website markup rendered below in Preview.",
                returnValue = "${rawCode.lines().size} lines of markup",
                executionTimeMs = elapsed,
                securityBadge = "SANDBOX SECURED • Static markup, no scripts executed on-device",
                htmlPreview = rawCode
            )
        }

        // 1. Exploit / sandbox validation
        for (bad in forbiddenKeywords) {
            if (lower.contains(bad)) {
                return CodeExecutionResult(
                    isSuccess = false,
                    stdout = "",
                    returnValue = "SECURITY_VIOLATION",
                    executionTimeMs = System.currentTimeMillis() - startTime,
                    securityBadge = "BLOCKED • Unauthorized API access attempt ($bad)",
                    errorMessage = "Access to system internals or reflection is strictly prohibited in Phoenix Sandbox."
                )
            }
        }

        val stdoutList = mutableListOf<String>()
        val variables = mutableMapOf<String, Any>()

        // Pre-populate mathematical constants
        variables["pi"] = Math.PI
        variables["e"] = Math.E

        return try {
            val lines = rawCode.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("//") && !it.startsWith("#") }
            var lastValue: Any? = null
            var stepCount = 0
            val maxSteps = 5000

            for (line in lines) {
                stepCount++
                if (stepCount > maxSteps) {
                    throw IllegalStateException("Execution exceeded safe iteration budget (max $maxSteps steps).")
                }

                // Handle print / println
                if (line.startsWith("println(") || line.startsWith("print(") || line.startsWith("console.log(")) {
                    val content = extractParenthesesContent(line)
                    val evaluated = evaluateExpression(content, variables)
                    stdoutList.add(evaluated.toString())
                    lastValue = evaluated
                    continue
                }

                // Handle simple loop: repeat(n) { ... } or for i in 1..n
                if (line.startsWith("repeat(") && line.contains("{")) {
                    val countStr = line.substringAfter("repeat(").substringBefore(")").trim()
                    val count = evaluateExpression(countStr, variables).toString().toDoubleOrNull()?.toInt() ?: 1
                    val safeCount = count.coerceIn(0, 100)
                    val body = line.substringAfter("{").substringBeforeLast("}").trim()
                    repeat(safeCount) { idx ->
                        variables["it"] = idx
                        val loopRes = evaluateExpression(body, variables)
                        if (body.startsWith("print")) {
                            stdoutList.add(loopRes.toString())
                        }
                    }
                    lastValue = "Repeated $safeCount times"
                    continue
                }

                // Handle variable assignment: val x = 42 or x = 42
                if (line.contains("=") && !line.contains("==") && !line.contains("<=") && !line.contains(">=")) {
                    val cleanLine = line.removePrefix("val ").removePrefix("var ").removePrefix("let ").removePrefix("const ")
                    val parts = cleanLine.split("=", limit = 2)
                    val varName = parts[0].trim()
                    val expr = parts[1].trim()
                    val value = evaluateExpression(expr, variables)
                    variables[varName] = value
                    lastValue = value
                    continue
                }

                // Expression evaluation
                lastValue = evaluateExpression(line, variables)
            }

            val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            CodeExecutionResult(
                isSuccess = true,
                stdout = stdoutList.joinToString("\n"),
                returnValue = formatResultValue(lastValue),
                executionTimeMs = elapsed
            )
        } catch (e: Exception) {
            val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            CodeExecutionResult(
                isSuccess = false,
                stdout = stdoutList.joinToString("\n"),
                returnValue = "Execution Error",
                executionTimeMs = elapsed,
                errorMessage = e.message ?: "Evaluation exception"
            )
        }
    }

    private fun formatResultValue(value: Any?): String {
        if (value == null) return "void"
        if (value is Double) {
            return if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
        }
        return value.toString()
    }

    private fun extractParenthesesContent(line: String): String {
        val start = line.indexOf('(')
        val end = line.lastIndexOf(')')
        return if (start != -1 && end > start) {
            line.substring(start + 1, end).trim()
        } else ""
    }

    fun evaluateExpression(expr: String, vars: Map<String, Any>): Any {
        val trimmed = expr.trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")

        // Direct variable lookup
        if (vars.containsKey(trimmed)) {
            return vars[trimmed]!!
        }

        // Direct numeric literal
        val asDouble = trimmed.toDoubleOrNull()
        if (asDouble != null) {
            return if (asDouble % 1.0 == 0.0 && !trimmed.contains(".")) asDouble.toLong() else asDouble
        }

        // Boolean literals
        if (trimmed.equals("true", ignoreCase = true)) return true
        if (trimmed.equals("false", ignoreCase = true)) return false

        // Built-in safe math functions
        if (trimmed.startsWith("sqrt(") && trimmed.endsWith(")")) {
            val arg = evaluateExpression(trimmed.removeSurrounding("sqrt(", ")"), vars).toString().toDoubleOrNull() ?: 0.0
            return sqrt(arg)
        }
        if (trimmed.startsWith("abs(") && trimmed.endsWith(")")) {
            val arg = evaluateExpression(trimmed.removeSurrounding("abs(", ")"), vars).toString().toDoubleOrNull() ?: 0.0
            return abs(arg)
        }
        if (trimmed.startsWith("sin(") && trimmed.endsWith(")")) {
            val arg = evaluateExpression(trimmed.removeSurrounding("sin(", ")"), vars).toString().toDoubleOrNull() ?: 0.0
            return sin(arg)
        }
        if (trimmed.startsWith("cos(") && trimmed.endsWith(")")) {
            val arg = evaluateExpression(trimmed.removeSurrounding("cos(", ")"), vars).toString().toDoubleOrNull() ?: 0.0
            return cos(arg)
        }
        if (trimmed.startsWith("pow(") && trimmed.endsWith(")")) {
            val inner = trimmed.removeSurrounding("pow(", ")")
            val args = inner.split(",")
            if (args.size == 2) {
                val base = evaluateExpression(args[0], vars).toString().toDoubleOrNull() ?: 0.0
                val exp = evaluateExpression(args[1], vars).toString().toDoubleOrNull() ?: 0.0
                return base.pow(exp)
            }
        }
        if (trimmed.startsWith("round(") && trimmed.endsWith(")")) {
            val arg = evaluateExpression(trimmed.removeSurrounding("round(", ")"), vars).toString().toDoubleOrNull() ?: 0.0
            return round(arg)
        }

        // List operations: listOf(1, 2, 3).sum() or [1, 2, 3].sum()
        if (trimmed.contains(".sum()") || trimmed.contains(".sorted()") || trimmed.contains(".reversed()")) {
            val listPart = trimmed.substringBefore(".")
            val list = parseNumberList(listPart, vars)
            return when {
                trimmed.endsWith(".sum()") -> list.sum()
                trimmed.endsWith(".sorted()") -> list.sorted()
                trimmed.endsWith(".reversed()") -> list.reversed()
                trimmed.endsWith(".size") || trimmed.endsWith(".length") -> list.size
                else -> list
            }
        }

        // Binary Arithmetic operators (+, -, *, /, %, ^)
        val binaryOpResult = evaluateBinaryMath(trimmed, vars)
        if (binaryOpResult != null) return binaryOpResult

        // String concatenation with +
        if (trimmed.contains("+")) {
            val parts = trimmed.split("+")
            return parts.joinToString("") { evaluateExpression(it.trim(), vars).toString() }
        }

        // Fallback string literal
        return trimmed
    }

    private fun parseNumberList(raw: String, vars: Map<String, Any>): List<Double> {
        val clean = raw.removePrefix("listOf(").removePrefix("[").removeSuffix(")").removeSuffix("]").trim()
        if (clean.isBlank()) return emptyList()
        return clean.split(",").mapNotNull {
            val evaluated = evaluateExpression(it.trim(), vars)
            evaluated.toString().toDoubleOrNull()
        }
    }

    private fun evaluateBinaryMath(expression: String, vars: Map<String, Any>): Any? {
        // Precedence: +, - after *, /, %
        val ops = listOf("+", "-", "*", "/", "%", "^")
        for (op in listOf("+", "-")) {
            val idx = findOperatorIndex(expression, op)
            if (idx > 0 && idx < expression.length - 1) {
                val left = expression.substring(0, idx).trim()
                val right = expression.substring(idx + 1).trim()
                val lVal = evaluateExpression(left, vars).toString().toDoubleOrNull()
                val rVal = evaluateExpression(right, vars).toString().toDoubleOrNull()
                if (lVal != null && rVal != null) {
                    val res = if (op == "+") lVal + rVal else lVal - rVal
                    return if (res % 1.0 == 0.0) res.toLong() else res
                }
            }
        }

        for (op in listOf("*", "/", "%", "^")) {
            val idx = findOperatorIndex(expression, op)
            if (idx > 0 && idx < expression.length - 1) {
                val left = expression.substring(0, idx).trim()
                val right = expression.substring(idx + 1).trim()
                val lVal = evaluateExpression(left, vars).toString().toDoubleOrNull()
                val rVal = evaluateExpression(right, vars).toString().toDoubleOrNull()
                if (lVal != null && rVal != null) {
                    val res = when (op) {
                        "*" -> lVal * rVal
                        "/" -> if (rVal != 0.0) lVal / rVal else Double.NaN
                        "%" -> lVal % rVal
                        "^" -> lVal.pow(rVal)
                        else -> 0.0
                    }
                    return if (res % 1.0 == 0.0) res.toLong() else res
                }
            }
        }
        return null
    }

    private fun findOperatorIndex(str: String, op: String): Int {
        var parenDepth = 0
        for (i in str.indices) {
            val c = str[i]
            if (c == '(') parenDepth++
            else if (c == ')') parenDepth--
            else if (parenDepth == 0 && str.startsWith(op, i)) {
                // Ensure not part of a negative sign at the very beginning
                if (op == "-" && (i == 0 || str[i - 1] in "+-*/%^ ")) continue
                return i
            }
        }
        return -1
    }
}
